#ifndef STACK_CLASS_HPP
#define STACK_CLASS_HPP

// Necessary includes

template <typename T>
class Stack {
public:
    // default constructor
    // parameterized constructor that takes first item
    // copy constructor
    // move constructor
    // destructor
    // function empty; does not throw exceptions
    // function size; does not throw exceptions
    // function top; l-value; throws underflow if stack is empty
    // function top; read-only; throws underflow if stack is empty
    // function push; does not throw exceptions
    // function emplace; does not throw exceptions
    // function pop; throws underflow if stack is empty
    // copy assignment operator overload
    // move assignment operator overload
private:
    // Private data
};



// STACK FUNCTIONS



#endif