#include <iostream>
#include <utility>
#include "Album.hpp"
#include "Rando.hpp"
#include "Stack.hpp"
#include "test_interface.hpp"

int main()
{
    runTests();

    Rando<unsigned int> test;

    return 0;
}